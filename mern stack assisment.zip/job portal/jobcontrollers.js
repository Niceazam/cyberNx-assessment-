import Job from '../models/Job.js';

export const createJob = async (req, res) => {
  const job = new Job({ ...req.body, employer: req.user.id });
  await job.save();
  res.status(201).json(job);
};

export const getJobs = async (req, res) => {
  const { keyword, location } = req.query;
  const jobs = await Job.find({
    title: { $regex: keyword || '', $options: 'i' },
    location: { $regex: location || '', $options: 'i' }
  });
  res.json(jobs);
};

export const updateJob = async (req, res) => {
  const job = await Job.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(job);
};

export const deleteJob = async (req, res) => {
  await Job.findByIdAndDelete(req.params.id);
  res.json({ message: 'Job deleted' });
};

export const applyJob = async (req, res) => {
  const job = await Job.findById(req.params.id);
  job.applicants.push(req.user.id);
  await job.save();
  res.json({ message: 'Applied successfully' });
};

export const getApplicants = async (req, res) => {
  const job = await Job.findById(req.params.id).populate('applicants', 'name email');
  res.json(job.applicants);
};
