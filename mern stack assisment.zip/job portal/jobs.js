import express from 'express';
import {
  createJob,
  getJobs,
  updateJob,
  deleteJob,
  applyJob,
  getApplicants
} from '../controllers/jobController.js';
import { authMiddleware } from '../middleware/auth.js';

const router = express.Router();

router.post('/', authMiddleware, createJob);
router.get('/', getJobs);
router.put('/:id', authMiddleware, updateJob);
router.delete('/:id', authMiddleware, deleteJob);
router.post('/:id/apply', authMiddleware, applyJob);
router.get('/:id/applicants', authMiddleware, getApplicants);

export default router;
